package com.kreckapps.pendant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    // ******* Variable Definitions *******
    // Debugging variables
    private val TAG: String = "Kreck"

    // Bluetooth related variables
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val REQUEST_ENABLE_BT: Int = 1
    private val REQUEST_PERMISSION_BT: Int = 101
    private val HC05_ADDRESS: String = "00:21:13:02:B3:2A"
    private var pairedDevices: Set<BluetoothDevice>? = null
    private var bluetoothDevice: BluetoothDevice? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null

    // User interface variables
    private lateinit var btnBtConnect: Button
    private lateinit var btnStop: Button

    private lateinit var btnXPlus: Button
    private lateinit var btnXMinus: Button
    private lateinit var btnYPlus: Button
    private lateinit var btnYMinus: Button
    private lateinit var btnZPlus: Button
    private lateinit var btnZMinus: Button

    private lateinit var lbStepDistance: TextView
    private lateinit var etStepDist: EditText
    private lateinit var lbStepUnits: TextView

    private lateinit var lbFeedRate: TextView
    private lateinit var etFeedRate: EditText
    private lateinit var tvFOPerc: TextView
    private lateinit var tvFOVal: TextView
    private lateinit var sbFeedRate: SeekBar

    private lateinit var lbStepFeedSwtich: TextView
    private lateinit var swStepCont: Switch
    private lateinit var lbStepOpt: TextView
    private lateinit var lbFeedOpt: TextView

    // Movement variables
    private var isContinuous: Boolean = false
    private var stepDist: Float = 10.0f
    private var feedOvFrac: Float = 1.0f
    private var baseFeedRate: Int = 150
    private var calcFeedRate: Int = 150

    private val maxTravelX: Int = 150
    private val maxTravelY: Int = 150
    private val maxTravelZ: Int = 250
    private var activeAxis: String? = null
    private var isActive: Boolean = false


    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //window.statusBarColor = ContextCompat.getColor(this, R.color.black)

        // ******* Setting up UI elements *******
        // Buttons
        btnBtConnect = findViewById(R.id.btnBtConnect)
        btnBtConnect.text = "CONNECT"
        btnBtConnect.setOnClickListener { btnBtConnectCall() }

        btnStop = findViewById(R.id.btnStop)
        btnStop.text = "STOP"
        btnStop.setOnClickListener { btnStopCall() }

        btnXPlus = findViewById(R.id.btnXPlus)
        btnXPlus.text = "X +"
        btnXPlus.setOnClickListener { btnXPlusCall() }

        btnXMinus = findViewById(R.id.btnXMinus)
        btnXMinus.text = "X -"
        btnXMinus.setOnClickListener { btnXMinusCall() }

        btnYPlus = findViewById(R.id.btnYPlus)
        btnYPlus.text = "Y +"
        btnYPlus.setOnClickListener { btnYPlusCall() }

        btnYMinus = findViewById(R.id.btnYMinus)
        btnYMinus.text = "Y -"
        btnYMinus.setOnClickListener { btnYMinusCall() }

        btnZPlus = findViewById(R.id.btnZPlus)
        btnZPlus.text = "Z +"
        btnZPlus.setOnClickListener { btnZPlusCall() }

        btnZMinus = findViewById(R.id.btnZMinus)
        btnZMinus.text = "Z -"
        btnZMinus.setOnClickListener { btnZMinusCall() }

        // Feed Rate Box Elements
        lbFeedRate = findViewById(R.id.lbFeedRate)
        lbFeedRate.text = "Feed Rate:"

        tvFOPerc = findViewById(R.id.tvFOPerc)
        updateOverridePercentage(100)

        tvFOVal = findViewById(R.id.tvFOVal)
        updateFeedRate()

        etFeedRate = findViewById(R.id.etFeedRate)
        etFeedRate.setText("${baseFeedRate}")
        etFeedRate.setOnEditorActionListener(object : TextView.OnEditorActionListener {
            override fun onEditorAction(v: TextView?, actionId: Int, event: KeyEvent?): Boolean {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.hideSoftInputFromWindow(etFeedRate.windowToken, 0)
                    etFeedRate.clearFocus()

                    if (etFeedRate.text.toString() != "") {
                        baseFeedRate = Integer.parseInt(etFeedRate.text.toString())
                        sbFeedRate.progress = 10
                        feedOvFrac = 1.0f
                        updateFeedRate()
                        return true
                    } else {
                        etFeedRate.setText("${baseFeedRate}")
                    }
                }
                return false
            }
        })

        sbFeedRate = findViewById(R.id.sbFeedRate)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            sbFeedRate.min = 1
        }
        sbFeedRate.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, progress: Int, p2: Boolean) {
                updateOverridePercentage(progress * 10)
                feedOvFrac = (progress.toFloat() / 10)
                updateFeedRate()
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })

        //Step Distance Box Elements
        lbStepDistance = findViewById(R.id.lbStepDistance)
        lbStepDistance.text = "Step Distance:"

        lbStepUnits = findViewById(R.id.lbStepUnits)
        lbStepUnits.text = "mm"

        etStepDist = findViewById(R.id.etStepDist)
        etStepDist.setText("${stepDist}")
        etStepDist.setOnEditorActionListener(object : TextView.OnEditorActionListener {
            override fun onEditorAction(v: TextView?, actionId: Int, event: KeyEvent?): Boolean {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.hideSoftInputFromWindow(etStepDist.windowToken, 0)
                    etStepDist.clearFocus()

                    if (etStepDist.text.toString() != "") {
                        stepDist = etStepDist.text.toString().toFloat()
                        return true
                    } else {
                        etStepDist.setText("${stepDist}")
                    }
                }
                return false
            }
        })

        // Step/Jog Switch Box Elements
        lbStepFeedSwtich = findViewById(R.id.lbStepFeedSwitch)
        lbStepFeedSwtich.text = "Jog Style:"

        lbStepOpt = findViewById(R.id.lbStepOpt)
        lbStepOpt.text = "STEP"

        lbFeedOpt = findViewById(R.id.lbFeedOpt)
        lbFeedOpt.text = "FEED"
        lbFeedOpt.alpha = 0.4f

        swStepCont = findViewById(R.id.swStepCont)
        swStepCont.setOnCheckedChangeListener { _, switchVal ->
            isContinuous = switchVal
            if (isContinuous) {
                lbStepDistance.alpha = 0.4f
                etStepDist.isEnabled = false
                etStepDist.alpha = 0.4f
                lbStepUnits.alpha = 0.4f
                lbStepOpt.alpha = 0.4f
                lbFeedOpt.alpha = 1.0f
            } else {
                lbStepDistance.alpha = 1.0f
                etStepDist.isEnabled = true
                etStepDist.alpha = 1.0f
                lbStepUnits.alpha = 1.0f
                lbStepOpt.alpha = 1.0f
                lbFeedOpt.alpha = 0.4f
            }
        }

        // Disable necessary UI elements on startup
        disableUI()

        // ******* Setting up bluetooth connection *******
        // Initial check if the current device has bluetooth capability or not
        if (bluetoothAdapter == null) {
            // Case that device that does not support bluetooth
            Toast.makeText(this, "This device does not support bluetooth", Toast.LENGTH_LONG).show()
            return
        } else {
            // Manages bluetooth permission and enable state
            checkAndRequestBluetoothPermissions()

            // Check to verify that bluetooth permission has been granted, and bluetooth is currently enabled
            if (!isBluetoothEnabled()) {
                // Bluetooth enable has failed, halt process here
                return
            }

            // Get list of already paired bluetooth devices and search for HCO5 address
            pairedDevices = bluetoothAdapter.bondedDevices
            pairedDevices?.forEach { device ->
                val deviceName = device.name
                val deviceAddress = device.address
                if (deviceAddress == HC05_ADDRESS) {
                    bluetoothDevice = device
                }
            }

            // Check if HC05 module was found
            if (bluetoothDevice != null) {
                // HC05 module was found in paired devices list
                // Enable "Connect" button which calls btnBtConnectCall() function
                btnBtConnect.isEnabled = true
            } else {
                Log.d(TAG, "HC05 Module not paired")
                Toast.makeText(this, "HC05 not yet paired", Toast.LENGTH_SHORT).show()
                return
            }
        }
    }

    // ******* Additional class function definitions *******
    // Checks if bluetooth permission is already granted, and requests permission if not
    private fun checkAndRequestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Checking for bluetooth connect permission - the only dangerous level permission
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // Send bluetooth permission dialogue as permission is not given
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQUEST_PERMISSION_BT
                )
            } else {
                enableBluetooth()
            }
        } else {
            enableBluetooth()
        }
    }

    // Handles the users response to bluetooth permission request
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_PERMISSION_BT -> {
                if (grantResults.isNotEmpty() && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    // Bluetooth permission granted by user
                    enableBluetooth()
                } else {
                    // Case that bluetooth was denied by user
                    Log.d(TAG, "User has denied app bluetooth permissions")
                    Toast.makeText(this, "Bluetooth permission denied", Toast.LENGTH_SHORT).show()
                    return
                }
                return
            }
        }
    }

    // Enables bluetooth connectivity if currently disabled
    @SuppressLint("MissingPermission")
    private fun enableBluetooth() {
        if (bluetoothAdapter!!.isEnabled) {
            // Bluetooth was already enabled
        } else {
            // Case that bluetooth is not enabled
            Log.d(TAG, "Bluetooth is currently disabled")
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_OK) {
                return
            } else {
                Log.d(TAG, "User has denied to enable bluetooth")
                Toast.makeText(this, "Bluetooth enable denied", Toast.LENGTH_SHORT).show()
                return
            }
        }
    }

    // Checks if bluetooth is currently enabled
    private fun isBluetoothEnabled(): Boolean {
        return bluetoothAdapter?.isEnabled == true
    }

    // Attempt to connect to bluetooth device with address: HC05_ADDRESS
    @SuppressLint("MissingPermission")
    private fun connectToDevice() {
        val uuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        try {
            bluetoothSocket = bluetoothDevice?.createRfcommSocketToServiceRecord(uuid)
            bluetoothSocket?.connect()
            outputStream = bluetoothSocket?.outputStream
            Toast.makeText(this, "Connected to ${bluetoothDevice?.name}", Toast.LENGTH_SHORT).show()
            btnBtConnect.text = "DISCONNECT"
            enableUI()

        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(this, "Connection failed", Toast.LENGTH_SHORT).show()
            try {
                bluetoothSocket?.close()
                disableUI()
            } catch (closeException: IOException) {
                closeException.printStackTrace()
            }
        }
    }

    // Closes current bluetooth connection
    private fun closeConnection() {
        try {
            bluetoothSocket?.close()
            bluetoothSocket = null
            btnBtConnect.text = "CONNECT"
            disableUI()
        } catch (closeException: IOException) {
            closeException.printStackTrace()
        }
    }

    // Write passed bytes to bluetooth outputStream
    private fun writeString(data: String) {
        val formattedData: String = "${data}\r\n"
        try {
            outputStream?.write(formattedData.toByteArray(Charsets.UTF_8))
        } catch (e: IOException) {
            Log.e(TAG, "Error occurred with sending data", e)
        }
    }

    private fun writeByte(data: Byte) {
        try {
            outputStream?.write(byteArrayOf(data))
            outputStream?.write("\r\n".toByteArray(Charsets.UTF_8))
        } catch (e: IOException) {
            Log.e(TAG, "Error occurred with sending data", e)
        }
    }

    // Callback function for btnConnect
    private fun btnBtConnectCall() {
        if (bluetoothSocket == null) {
            connectToDevice()
            return
        } else {
            closeConnection()
            return
        }
    }

    // Callback function for btnXPlus
    private fun btnXPlusCall() {
        if (isContinuous) {
            writeString("${'$'}J = G21 G91 X${maxTravelX} F${calcFeedRate}")
        } else {
            writeString("${'$'}J = G21 G91 X${stepDist} F${calcFeedRate}")
        }
        isActive = true
        activeAxis = "X+"
    }

    // Callback function for btnXMinus
    private fun btnXMinusCall() {
        if (isContinuous) {
            writeString("${'$'}J = G21 G91 X-${maxTravelX} F${calcFeedRate}")
        } else {
            writeString("${'$'}J = G21 G91 X-${stepDist} F${calcFeedRate}")
        }
        isActive = true
        activeAxis = "X-"
    }

    // Callback function for btnYPlus
    private fun btnYPlusCall() {
        if (isContinuous) {
            writeString("${'$'}J = G21 G91 Y${maxTravelY} F${calcFeedRate}")
        } else {
            writeString("${'$'}J = G21 G91 Y${stepDist} F${calcFeedRate}")
        }
        isActive = true
        activeAxis = "Y+"
    }

    // Callback function for btnYMinus
    private fun btnYMinusCall() {
        if (isContinuous) {
            writeString("${'$'}J = G21 G91 Y-${maxTravelY} F${calcFeedRate}")
        } else {
            writeString("${'$'}J = G21 G91 Y-${stepDist} F${calcFeedRate}")
        }
        isActive = true
        activeAxis = "Y-"
    }

    // Callback function for btnZPlus
    private fun btnZPlusCall() {
        if (isContinuous) {
            writeString("${'$'}J = G21 G91 Z${maxTravelZ} F${calcFeedRate}")
        } else {
            writeString("${'$'}J = G21 G91 Z${stepDist} F${calcFeedRate}")
        }
        isActive = true
        activeAxis = "Z+"
    }

    // Callback function for btnZMinus
    private fun btnZMinusCall() {
        if (isContinuous) {
            writeString("${'$'}J = G21 G91 Z-${maxTravelZ} F${calcFeedRate}")
        } else {
            writeString("${'$'}J = G21 G91 Z-${stepDist} F${calcFeedRate}")
        }
        isActive = true
        activeAxis = "Z-"
    }

    // Callback function for btnStop
    private fun btnStopCall() {
        writeByte(0x85.toByte())
        isActive = false
    }


    // Updates the feed rate override percentage with the passed value
    private fun updateOverridePercentage(percent: Int) {
        tvFOPerc.text = "x   ( ${percent} % )   ="
    }

    // Calculates feed rate after base value change or override value change
    private fun updateFeedRate() {
        calcFeedRate = (feedOvFrac * baseFeedRate).roundToInt()
        tvFOVal.text = "${calcFeedRate}   mm/min"

        if (isContinuous && isActive) {
            btnStopCall()

            when (activeAxis) {
                "X+" -> btnXPlusCall()
                "X-" -> btnXMinusCall()
                "Y+" -> btnYPlusCall()
                "Y-" -> btnYMinusCall()
                "Z+" -> btnZPlusCall()
                "Z-" -> btnZMinusCall()
            }
        }
    }

    // After bluetooth connection established, enable all UI elements
    private fun enableUI() {
        btnStop.isEnabled = true
        btnStop.alpha = 1.0f
        btnXPlus.isEnabled = true
        btnXPlus.alpha = 1.0f
        btnXMinus.isEnabled = true
        btnXMinus.alpha = 1.0f
        btnYPlus.isEnabled = true
        btnYPlus.alpha = 1.0f
        btnYMinus.isEnabled = true
        btnYMinus.alpha = 1.0f
        btnZPlus.isEnabled = true
        btnZPlus.alpha = 1.0f
        btnZMinus.isEnabled = true
        btnZMinus.alpha = 1.0f
        sbFeedRate.isEnabled = true
        sbFeedRate.alpha = 1.0f
    }

    // After bluetooth connection is terminated, disable all UI elements
    private fun disableUI() {
        btnStop.isEnabled = false
        btnStop.alpha = 0.4f
        btnXPlus.isEnabled = false
        btnXPlus.alpha = 0.4f
        btnXMinus.isEnabled = false
        btnXMinus.alpha = 0.4f
        btnYPlus.isEnabled = false
        btnYPlus.alpha = 0.4f
        btnYMinus.isEnabled = false
        btnYMinus.alpha = 0.4f
        btnZPlus.isEnabled = false
        btnZPlus.alpha = 0.4f
        btnZMinus.isEnabled = false
        btnZMinus.alpha = 0.4f
        sbFeedRate.isEnabled = false
        sbFeedRate.alpha = 0.4f
    }
}